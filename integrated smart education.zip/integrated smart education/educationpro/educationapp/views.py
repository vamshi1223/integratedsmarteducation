from django.contrib.auth import logout
from .models import Feedback, Contact
# Create your views here.
from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages

def adminlogin(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Check if the email and password match the expected credentials
        if email == 'admin@gmail.com' and password == 'adminstd':
            return redirect('admindashboard')  # Redirect to the admin dashboard
        else:
            messages.error(request, 'Invalid email or password')
    return render(request, './adminportal/adminlogin.html')  # Render the login template

# admindashboard
def admindashboard(request):
    return render (request,"./adminportal/admindashboard.html")

def contact(request):
    if request.method == "POST":
        firstname = request.POST.get("firstname")
        lastname = request.POST.get("lastname")
        phonenumber = request.POST.get("phonenumber")
        email = request.POST.get("email")
        yourmessage = request.POST.get("yourmessage")
        # Save the data to the Feedback model
        contact_entry = Contact(firstname=firstname, lastname=lastname,phonenumber=phonenumber, email=email, yourmessage=yourmessage)
        contact_entry.save()
    return render (request,"./userportal/contact.html")

def nav(request):
    return render (request,"./userportal/nav.html")

def home(request):
    return render (request,"./userportal/home.html")

def feedback(request):
     if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        message = request.POST.get("message")
        # Save the data to the Feedback model
        feedback_entry = Feedback(name=name, email=email, message=message)
        feedback_entry.save()
     return render(request, "./userportal/feedback.html")

from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from .models import CustomUser
import random
from django.shortcuts import render, redirect
from .models import CustomUser

def generate_user_id(username):
    # Generate a simple user ID based on username and random number
    user_id = f'{username[:3]}{random.randint(1000, 9999)}'
    return user_id
from django.shortcuts import render, redirect
from .models import CustomUser
from django.shortcuts import render, redirect
from .models import CustomUser

from django.shortcuts import render, redirect
from .models import CustomUser

def signup_view(request):
    if request.method == 'POST':
        full_name = request.POST['full_name']
        email = request.POST['email']
        username = request.POST['username']
        grade = request.POST['grade']
        password = request.POST['password']

        # Create the user
        user = CustomUser.objects.create_user(
            email=email,
            username=username,
            full_name=full_name,
            grade=grade,  # Save the grade field
            password=password,
        )

        return redirect('login')  # Redirect to login after successful signup

    return render(request, 'userportal/signup.html')



from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect

from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        # Authenticate user
        user = authenticate(request, email=email, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Redirect to the home page or another page after login
        else:
            # Authentication failed
            return render(request, './userportal/userlogin.html', {'error': 'Invalid email or password.'})
    return render(request, './userportal/userlogin.html')
def logout_view(request):
    logout(request)
    return redirect('login')  # Redirect to the login page after logout
def profile_view(request):
    if not request.user.is_authenticated:
        return redirect('login')
    # Assuming your CustomUser model has a 'full_name' field
    user_profile = {
        'full_name': request.user.full_name,
        'email': request.user.email,
        # Add more fields as necessary
    }
    return render(request, './userportal/profile.html', {'user_profile': user_profile})
from django.shortcuts import render, redirect, get_object_or_404
from .models import CustomUser

def student_details_view(request):
    students_by_grade = {}
    users = CustomUser.objects.all()

    for user in users:
        grade = user.grade
        if grade not in students_by_grade:
            students_by_grade[grade] = []
        students_by_grade[grade].append(user)
    
    return render(request, 'adminportal/student_details.html', {'students_by_grade': students_by_grade})

def edit_user_view(request, user_id):
    user = get_object_or_404(CustomUser, id=user_id)
    
    if request.method == 'POST':
        user.email = request.POST['email']
        user.username = request.POST['username']
        user.full_name = request.POST['full_name']
        user.grade = request.POST['grade']
        user.save()
        return redirect('student_details')

    return render(request, 'adminportal/edit_user.html', {'user': user})

def delete_user_view(request, user_id):
    user = get_object_or_404(CustomUser, id=user_id)
    
    if request.method == 'POST':
        user.delete()
        return redirect('student_details')

    return render(request, 'adminportal/student_details.html')


#teacher
from django.shortcuts import render, redirect, get_object_or_404
from .models import Teacher
from django.http import HttpResponse

def teacher_management(request):
    teachers = Teacher.objects.all()
    return render(request, './adminportal/teacher_management.html', {'teachers': teachers})

def add_teacher(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        address = request.POST.get('address')
        age = request.POST.get('age')
        if name and email and address and age:
            Teacher.objects.create(name=name, email=email, address=address, age=age)
            return redirect('teacher_management')
        else:
            return HttpResponse("Error: All fields are required.", status=400)
    return render(request, './adminportal/add_teacher.html')
def edit_teacher(request, pk):
    teacher = get_object_or_404(Teacher, pk=pk)
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        if name and email:
            teacher.name = name
            teacher.email = email
            teacher.save()
            return redirect('teacher_management')
        else:
            return HttpResponse("Error: Name and email are required.", status=400)
    return render(request, './adminportal/edit_teacher.html', {'teacher': teacher})

def delete_teacher(request, pk):
    teacher = get_object_or_404(Teacher, pk=pk)
    if request.method == 'POST':
        teacher.delete()
        return redirect('teacher_management')
    return render(request, './adminportal/confirm_delete.html', {'teacher': teacher})
